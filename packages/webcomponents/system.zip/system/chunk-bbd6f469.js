System.register([],function(e,t){"use strict";return{execute:function(){e({a:function(e,t){return e(t={exports:{}},t.exports),t.exports},c:function(e){return e&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,"default")?e.default:e}});e("b","undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof self?self:{})}}});
//# sourceMappingURL=chunk-bbd6f469.js.map
